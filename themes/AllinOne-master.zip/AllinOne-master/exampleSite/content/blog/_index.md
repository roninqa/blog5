+++
date = "2018-09-13T22:31:21+08:00"
draft = false
title = "Blog"

+++

`Blog` is the place to record my life. There are 5 categories in `Blog` section:

- Thoughts: My thoughts and attitude to everything in my life.

- Critique: My reviews, especially to musicals, movies, etc.

- Travel: My travel notes.

- Moment: Some moments that I feel something and eager to write it down. Fragments in my life. Short memos.

- Gallery: Pictures I'd like to share. My favourite ones.